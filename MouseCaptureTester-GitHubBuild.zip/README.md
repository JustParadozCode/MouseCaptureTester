# MouseCapture Tester (Android)

A small Android diagnostic app for testing USB/Bluetooth mouse input and Android Pointer Capture.

## Open in Android Studio
1. Extract this ZIP.
2. Open the `MouseCaptureTester` folder in Android Studio.
3. Let Gradle sync. Android Studio may download the Android Gradle Plugin and SDK components.
4. Connect your Android device with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your own device.

## Test
1. Connect your USB OTG mouse.
2. Move it over the test area and inspect the event log.
3. Press **CAPTURE MOUSE** and move the mouse.
4. Check whether the status changes to POINTER CAPTURE ACTIVE and whether the cursor disappears.
5. Test left/right click and press RELEASE to exit capture.

## Important limitations
- This app can only capture pointer input while this app is in the foreground.
- Android apps cannot normally request pointer capture for another app's window.
- It does not patch Roblox, inject input into Roblox, or bypass Android security.
- The app is a diagnostic tool; it cannot guarantee a fix for Roblox's own Android mouse handling.

## Requirements
- Android 8.0 (API 26) or newer
- Android Studio with Android SDK 35
- Kotlin / Android Gradle Plugin versions are declared in the Gradle files
