package com.paradox.mousecapture

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var testSurface: TextView
    private lateinit var statusText: TextView
    private lateinit var modeText: TextView
    private lateinit var positionText: TextView
    private lateinit var deltaText: TextView
    private lateinit var buttonText: TextView
    private lateinit var deviceText: TextView
    private lateinit var logText: TextView

    private var captured = false
    private var lastX = 0f
    private var lastY = 0f
    private var totalX = 0f
    private var totalY = 0f
    private var moveCount = 0
    private var lastButton = "None"
    private var lastAction = "Waiting for mouse input"

    private val bg = Color.rgb(16, 19, 26)
    private val panel = Color.rgb(29, 34, 45)
    private val accent = Color.rgb(190, 170, 255)
    private val white = Color.rgb(242, 243, 248)
    private val muted = Color.rgb(170, 178, 194)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(14), dp(18), dp(16))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        content.addView(label("MOUSECAPTURE", 25, accent, true))
        content.addView(label("ANDROID INPUT DIAGNOSTIC  •  v1.0", 11, muted))
        content.addView(space(14))

        statusText = panelText("Status: waiting", 16, white, true)
        content.addView(statusText)
        modeText = panelText("Mode: normal mouse input", 14, muted)
        content.addView(modeText)
        content.addView(space(12))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val captureButton = makeButton("CAPTURE MOUSE") {
            if (Build.VERSION.SDK_INT >= 26) {
                testSurface.requestPointerCapture()
                lastAction = "Requested pointer capture"
                updateUi()
            }
        }
        val releaseButton = makeButton("RELEASE") {
            if (Build.VERSION.SDK_INT >= 26) {
                testSurface.releasePointerCapture()
            }
            captured = false
            lastAction = "Released pointer capture"
            updateUi()
        }
        buttons.addView(captureButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(releaseButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginStart = dp(8)
        })
        content.addView(buttons)
        content.addView(space(10))

        content.addView(label("MOVE YOUR MOUSE INSIDE THIS AREA", 12, accent, true))
        testSurface = TextView(this).apply {
            text = "Mouse test area\n\nMove the mouse here.\nRight-click and left-click to test."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(white)
            setBackgroundColor(Color.rgb(48, 55, 72))
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener {
                requestFocus()
                lastAction = "Test area tapped"
                updateUi()
            }
        }
        testSurface.setOnPointerCaptureChangeListener { _, hasCapture ->
            captured = hasCapture
            lastAction = if (hasCapture) "Pointer capture ACTIVE" else "Pointer capture INACTIVE"
            updateUi()
        }
        testSurface.setOnGenericMotionListener { _, event ->
            handleMouseEvent(event)
            true
        }
        content.addView(testSurface, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(190)
        ))
        content.addView(space(12))

        positionText = panelText("Position: —", 14, white)
        deltaText = panelText("Relative delta: —", 14, white)
        buttonText = panelText("Buttons: none", 14, white)
        deviceText = panelText("Device: waiting for input", 14, white)
        content.addView(positionText)
        content.addView(deltaText)
        content.addView(buttonText)
        content.addView(deviceText)
        content.addView(space(12))

        content.addView(label("EVENT LOG", 12, accent, true))
        logText = panelText("No events yet.", 12, muted)
        content.addView(logText)
        content.addView(space(12))

        content.addView(makeButton("RESET COUNTERS") {
            totalX = 0f; totalY = 0f; moveCount = 0
            lastAction = "Counters reset"
            updateUi()
        })
        content.addView(space(12))
        content.addView(label(
            "HOW TO TEST\n1. Move the mouse over the test area.\n" +
            "2. Click CAPTURE MOUSE and move it again.\n" +
            "3. Try left-click and right-click.\n" +
            "4. Press RELEASE to return to normal mode.\n\n" +
            "If capture works, Android should report captured pointer events and hide the normal pointer while captured.",
            13, muted
        ))
        content.addView(space(10))
        content.addView(label(
            "Note: This app tests Android input only. It cannot force Roblox to capture its own window or change Roblox's internal mouse handling.",
            12, Color.rgb(255, 205, 130)
        ))

        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        testSurface.requestFocus()
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun panelText(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
            if (bold) setTypeface(null, Typeface.BOLD)
            val p = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            p.bottomMargin = dp(6)
            layoutParams = p
        }

    private fun makeButton(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE) ||
            event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)) {
            handleMouseEvent(event)
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE) ||
            event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)) {
            handleMouseEvent(event)
            return true
        }
        return super.onTouchEvent(event)
    }

    private fun handleMouseEvent(event: MotionEvent) {
        val actionName = when (event.actionMasked) {
            MotionEvent.ACTION_MOVE -> "MOVE"
            MotionEvent.ACTION_HOVER_MOVE -> "HOVER_MOVE"
            MotionEvent.ACTION_BUTTON_PRESS -> "BUTTON_PRESS"
            MotionEvent.ACTION_BUTTON_RELEASE -> "BUTTON_RELEASE"
            MotionEvent.ACTION_SCROLL -> "SCROLL"
            MotionEvent.ACTION_DOWN -> "DOWN"
            MotionEvent.ACTION_UP -> "UP"
            else -> "ACTION_${event.actionMasked}"
        }

        val relX = if (Build.VERSION.SDK_INT >= 26)
            event.getAxisValue(MotionEvent.AXIS_RELATIVE_X) else 0f
        val relY = if (Build.VERSION.SDK_INT >= 26)
            event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y) else 0f

        if (event.actionMasked == MotionEvent.ACTION_MOVE) {
            moveCount++
            if (captured || relX != 0f || relY != 0f) {
                totalX += relX
                totalY += relY
            } else {
                totalX += event.x - lastX
                totalY += event.y - lastY
            }
        }
        lastX = event.x
        lastY = event.y

        val buttons = mutableListOf<String>()
        if (event.buttonState and MotionEvent.BUTTON_PRIMARY != 0) buttons.add("LEFT")
        if (event.buttonState and MotionEvent.BUTTON_SECONDARY != 0) buttons.add("RIGHT")
        if (event.buttonState and MotionEvent.BUTTON_TERTIARY != 0) buttons.add("MIDDLE")
        lastButton = buttons.joinToString().ifEmpty { "None" }

        val sourceName = buildString {
            if (event.isFromSource(InputDevice.SOURCE_MOUSE)) append("MOUSE ")
            if (event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)) append("RELATIVE ")
            if (event.isFromSource(InputDevice.SOURCE_TOUCHSCREEN)) append("TOUCH ")
        }.ifBlank { "Other" }

        lastAction = "$actionName • ${event.eventTime}"
        deviceText.text = "Device: ${event.device?.name ?: "Unknown"} | $sourceName"
        logText.text = "Last event: $actionName\n" +
            "Action index: ${event.actionIndex}\n" +
            "Button state: ${event.buttonState}\n" +
            "Scroll V/H: ${fmt(event.getAxisValue(MotionEvent.AXIS_VSCROLL))} / " +
            fmt(event.getAxisValue(MotionEvent.AXIS_HSCROLL))
        updateUi(relX, relY)
    }

    private fun fmt(value: Float) = String.format(Locale.US, "%.2f", value)

    private fun updateUi(relX: Float = 0f, relY: Float = 0f) {
        if (!::statusText.isInitialized) return
        statusText.text = if (captured) "Status: POINTER CAPTURE ACTIVE" else "Status: not captured"
        modeText.text = "Mode: ${if (captured) "relative pointer capture" else "normal mouse input"}"
        positionText.text = "Position: X ${fmt(lastX)}  •  Y ${fmt(lastY)}"
        deltaText.text = "Relative delta: X ${fmt(relX)}  •  Y ${fmt(relY)}\n" +
            "Accumulated movement: X ${fmt(totalX)}  •  Y ${fmt(totalY)}\n" +
            "Move events: $moveCount"
        buttonText.text = "Buttons: $lastButton"
        if (::logText.isInitialized && lastAction.isNotBlank() && logText.text == "No events yet.") {
            logText.text = lastAction
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && captured) {
            if (Build.VERSION.SDK_INT >= 26) testSurface.releasePointerCapture()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        if (Build.VERSION.SDK_INT >= 26 && ::testSurface.isInitialized) {
            testSurface.releasePointerCapture()
        }
        super.onPause()
    }
}
